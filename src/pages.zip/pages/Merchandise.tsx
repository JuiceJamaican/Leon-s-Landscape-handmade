import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowLeft, ShoppingBag } from "lucide-react";

const merchItems = [
  {
    id: 1,
    title: "Leon's Branded Hat",
    price: "$25.00",
    description: "High-quality baseball cap with embroidered logo. One size fits all.",
    image: "/attached_assets/stock_images/branded_baseball_hat_9259af39.jpg"
  },
  {
    id: 2,
    title: "Official Work Tee",
    price: "$20.00",
    description: "Heavyweight cotton t-shirt. Durable enough for the job site.",
    image: "/attached_assets/stock_images/professional_cotton__6654e0bf.jpg"
  },
  {
    id: 3,
    title: "Signature Hoodie",
    price: "$45.00",
    description: "Cozy fleece-lined hoodie. Perfect for early morning starts.",
    image: "/attached_assets/stock_images/cozy_hooded_sweatshi_bc37e81a.jpg"
  }
];

export default function Merchandise() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/" className="inline-flex items-center gap-2 text-neutral-400 hover:text-black transition-colors text-sm font-medium tracking-wide mb-8">
          <ArrowLeft size={16} /> BACK TO HOME
        </Link>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-5xl md:text-6xl text-neutral-900 mb-4">Support Us</h1>
          <p className="text-xl text-neutral-500 font-light max-w-2xl mx-auto">
            Grab some official gear and show your support for Leon's Landscape Supplies.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
          {merchItems.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group"
            >
              <div className="aspect-[4/5] rounded-lg overflow-hidden bg-neutral-100 mb-4 shadow-sm group-hover:shadow-md transition-shadow">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-serif text-xl">{item.title}</h3>
                <span className="font-medium">{item.price}</span>
              </div>
              <p className="text-neutral-500 text-sm font-light mb-4">{item.description}</p>
              <button className="w-full py-3 bg-black text-white text-xs font-medium tracking-widest hover:bg-neutral-800 transition-all rounded-sm flex items-center justify-center gap-2">
                <ShoppingBag size={14} /> COMING SOON
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
